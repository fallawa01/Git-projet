# Advance  Multi Language Support Laravel 8 Ecommerce Project
## Website Live Preview
[`click`](https://shopbd.imzuyel.com/)

## Frontend
![E-mart-Happy-to-shop](https://user-images.githubusercontent.com/43112820/165052737-ff066b7e-56fb-4afa-92cb-402e3bf02f49.png)

## Backend
![E-mart _ All Products](https://user-images.githubusercontent.com/43112820/167244354-de1bd266-ae91-410a-8979-f4daa201f2f2.png)
